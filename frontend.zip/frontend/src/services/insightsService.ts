import type { AIRecommendation, SpendingAnalysis, FinancialScore } from '../types';

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const insightsService = {
  async getRecommendations(): Promise<AIRecommendation[]> {
    await delay(400);
    return [
      {
        id: 'rec_001',
        title: 'Reduce dining expenses',
        description:
          'Your food spending is 23% above your monthly average. Consider meal prepping to save approximately $180/month.',
        category: 'spending',
        priority: 'high',
        potentialSavings: 180,
        actionLabel: 'View breakdown',
      },
      {
        id: 'rec_002',
        title: 'Increase emergency fund',
        description:
          'Your savings rate is healthy at 62%, but your emergency fund covers only 2.5 months of expenses. Aim for 3–6 months.',
        category: 'savings',
        priority: 'medium',
        actionLabel: 'Set savings goal',
      },
      {
        id: 'rec_003',
        title: 'Optimize subscription costs',
        description:
          'You have 4 recurring subscriptions totaling $89/month. Two appear underutilized based on usage patterns.',
        category: 'budget',
        priority: 'medium',
        potentialSavings: 35,
        actionLabel: 'Review subscriptions',
      },
      {
        id: 'rec_004',
        title: 'Diversify investment income',
        description:
          'Investment income represents 3.2% of total income. Consider increasing contributions to your index fund portfolio.',
        category: 'investment',
        priority: 'low',
        actionLabel: 'Explore options',
      },
    ];
  },

  async getSpendingAnalysis(): Promise<SpendingAnalysis[]> {
    await delay(300);
    return [
      {
        id: 'spa_001',
        title: 'Monthly Spending',
        value: '$3,247',
        change: -8.2,
        changeLabel: 'vs last month',
        trend: 'down',
      },
      {
        id: 'spa_002',
        title: 'Daily Average',
        value: '$108',
        change: 3.1,
        changeLabel: 'vs last month',
        trend: 'up',
      },
      {
        id: 'spa_003',
        title: 'Top Category',
        value: 'Food & Dining',
        change: 23,
        changeLabel: 'above average',
        trend: 'up',
      },
      {
        id: 'spa_004',
        title: 'Recurring Costs',
        value: '$289/mo',
        change: 0,
        changeLabel: 'unchanged',
        trend: 'neutral',
      },
    ];
  },

  async getFinancialScore(): Promise<FinancialScore> {
    await delay(350);
    return {
      overall: 78,
      categories: [
        { label: 'Savings Rate', score: 85, maxScore: 100 },
        { label: 'Spending Control', score: 72, maxScore: 100 },
        { label: 'Income Stability', score: 90, maxScore: 100 },
        { label: 'Debt Management', score: 65, maxScore: 100 },
      ],
      lastUpdated: new Date().toISOString(),
    };
  },
};
