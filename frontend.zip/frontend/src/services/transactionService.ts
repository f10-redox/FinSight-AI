import type {
  Transaction,
  TransactionFilters,
  CreateTransactionPayload,
  DashboardStats,
  ChartDataPoint,
  CategoryDataPoint,
  TrendDataPoint,
} from '../types';

const TRANSACTIONS: Transaction[] = [
  {
    id: 'txn_001',
    description: 'Monthly Salary',
    amount: 8500,
    type: 'income',
    category: 'salary',
    status: 'completed',
    date: '2026-06-01',
    merchant: 'TechCorp Inc.',
  },
  {
    id: 'txn_002',
    description: 'Grocery Shopping',
    amount: 156.42,
    type: 'expense',
    category: 'food',
    status: 'completed',
    date: '2026-06-02',
    merchant: 'Whole Foods',
  },
  {
    id: 'txn_003',
    description: 'Freelance Project',
    amount: 2200,
    type: 'income',
    category: 'freelance',
    status: 'completed',
    date: '2026-05-28',
    merchant: 'Design Studio',
  },
  {
    id: 'txn_004',
    description: 'Electric Bill',
    amount: 89.5,
    type: 'expense',
    category: 'utilities',
    status: 'completed',
    date: '2026-05-27',
    merchant: 'City Power',
  },
  {
    id: 'txn_005',
    description: 'Netflix Subscription',
    amount: 15.99,
    type: 'expense',
    category: 'entertainment',
    status: 'completed',
    date: '2026-05-25',
    merchant: 'Netflix',
  },
  {
    id: 'txn_006',
    description: 'Uber Ride',
    amount: 24.8,
    type: 'expense',
    category: 'transport',
    status: 'completed',
    date: '2026-05-24',
    merchant: 'Uber',
  },
  {
    id: 'txn_007',
    description: 'Stock Dividend',
    amount: 340,
    type: 'income',
    category: 'investment',
    status: 'completed',
    date: '2026-05-22',
    merchant: 'Vanguard',
  },
  {
    id: 'txn_008',
    description: 'Gym Membership',
    amount: 49.99,
    type: 'expense',
    category: 'health',
    status: 'completed',
    date: '2026-05-20',
    merchant: 'Equinox',
  },
  {
    id: 'txn_009',
    description: 'Amazon Purchase',
    amount: 127.35,
    type: 'expense',
    category: 'shopping',
    status: 'pending',
    date: '2026-05-18',
    merchant: 'Amazon',
  },
  {
    id: 'txn_010',
    description: 'Restaurant Dinner',
    amount: 78.5,
    type: 'expense',
    category: 'food',
    status: 'completed',
    date: '2026-05-15',
    merchant: 'Nobu',
  },
  {
    id: 'txn_011',
    description: 'Consulting Fee',
    amount: 1500,
    type: 'income',
    category: 'freelance',
    status: 'completed',
    date: '2026-05-10',
    merchant: 'StartupXYZ',
  },
  {
    id: 'txn_012',
    description: 'Phone Bill',
    amount: 65,
    type: 'expense',
    category: 'utilities',
    status: 'completed',
    date: '2026-05-08',
    merchant: 'Verizon',
  },
];

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

let transactions = [...TRANSACTIONS];

const CATEGORY_COLORS: Record<string, string> = {
  food: '#f59e0b',
  transport: '#635bff',
  utilities: '#06b6d4',
  entertainment: '#8b5cf6',
  shopping: '#ef4444',
  health: '#22c55e',
  salary: '#22c55e',
  freelance: '#635bff',
  investment: '#8b5cf6',
  other: '#71717a',
};

export const transactionService = {
  async getAll(): Promise<Transaction[]> {
    await delay(400);
    return [...transactions].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
    );
  },

  async getFiltered(filters: TransactionFilters): Promise<Transaction[]> {
    const all = await transactionService.getAll();
    return all.filter((txn) => {
      const matchesSearch =
        filters.search === '' ||
        txn.description.toLowerCase().includes(filters.search.toLowerCase()) ||
        txn.merchant?.toLowerCase().includes(filters.search.toLowerCase());
      const matchesType = filters.type === 'all' || txn.type === filters.type;
      const matchesCategory =
        filters.category === 'all' || txn.category === filters.category;
      const matchesStatus =
        filters.status === 'all' || txn.status === filters.status;
      return matchesSearch && matchesType && matchesCategory && matchesStatus;
    });
  },

  async getRecent(limit = 5): Promise<Transaction[]> {
    const all = await transactionService.getAll();
    return all.slice(0, limit);
  },

  async create(payload: CreateTransactionPayload): Promise<Transaction> {
    await delay(500);
    const newTxn: Transaction = {
      id: `txn_${Date.now()}`,
      ...payload,
      status: 'completed',
    };
    transactions = [newTxn, ...transactions];
    return newTxn;
  },

  async getDashboardStats(): Promise<DashboardStats> {
    await delay(300);
    const income = transactions
      .filter((t) => t.type === 'income' && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0);
    const expenses = transactions
      .filter((t) => t.type === 'expense' && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0);
    const savings = income - expenses;
    return {
      currentBalance: 24850.75,
      income,
      expenses,
      savings,
      savingsRate: income > 0 ? (savings / income) * 100 : 0,
    };
  },

  async getIncomeVsExpensesChart(): Promise<ChartDataPoint[]> {
    await delay(200);
    return [
      { name: 'Jan', income: 9200, expenses: 4100 },
      { name: 'Feb', income: 8800, expenses: 3800 },
      { name: 'Mar', income: 9500, expenses: 4200 },
      { name: 'Apr', income: 9100, expenses: 3900 },
      { name: 'May', income: 10700, expenses: 4500 },
      { name: 'Jun', income: 8500, expenses: 3200 },
    ];
  },

  async getSpendingCategories(): Promise<CategoryDataPoint[]> {
    await delay(200);
    const categoryTotals: Record<string, number> = {};
    transactions
      .filter((t) => t.type === 'expense')
      .forEach((t) => {
        categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
      });
    return Object.entries(categoryTotals)
      .map(([name, value]) => ({
        name: name.charAt(0).toUpperCase() + name.slice(1),
        value: Math.round(value * 100) / 100,
        color: CATEGORY_COLORS[name] || CATEGORY_COLORS.other,
      }))
      .sort((a, b) => b.value - a.value);
  },

  async getMonthlyTrend(): Promise<TrendDataPoint[]> {
    await delay(200);
    return [
      { month: 'Jan', balance: 18200 },
      { month: 'Feb', balance: 19800 },
      { month: 'Mar', balance: 21100 },
      { month: 'Apr', balance: 22400 },
      { month: 'May', balance: 23600 },
      { month: 'Jun', balance: 24850 },
    ];
  },
};
