import type { User, UserProfile } from '../types';

const STORAGE_KEY = 'finsight_auth_user';
const TOKEN_KEY = 'finsight_jwt';

const API_URL = 'https://localhost:7015/api/Auth';

type AuthResponse = {
  token: string;
};

export const authService = {
  async login(email: string, password: string): Promise<User> {
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        password,
      }),
    });

    if (!response.ok) {
      throw new Error('Login failed');
    }

    const data: AuthResponse = await response.json();

    localStorage.setItem(TOKEN_KEY, data.token);

    const user: User = {
      id: crypto.randomUUID(),
      email,
      firstName: 'User',
      lastName: '',
      createdAt: new Date().toISOString(),
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));

    return user;
  },

  async register(
    firstName: string,
    lastName: string,
    email: string,
    password: string,
  ): Promise<User> {
    const response = await fetch(`${API_URL}/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        firstName,
        lastName,
        email,
        password,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(error);
    }

    const data: AuthResponse = await response.json();

    localStorage.setItem(TOKEN_KEY, data.token);

    const user: User = {
      id: crypto.randomUUID(),
      email,
      firstName,
      lastName,
      createdAt: new Date().toISOString(),
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));

    return user;
  },

  logout(): void {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(TOKEN_KEY);
  },

  getStoredUser(): User | null {
    const stored = localStorage.getItem(STORAGE_KEY);

    if (!stored) return null;

    try {
      return JSON.parse(stored) as User;
    } catch {
      return null;
    }
  },

  async getProfile(): Promise<UserProfile> {
    const stored = authService.getStoredUser();

    if (!stored) {
      throw new Error('Not authenticated');
    }

    return {
      ...stored,
      settings: {
        currency: 'USD',
        timezone: 'America/New_York',
        notifications: {
          email: true,
          push: true,
          weeklyReport: true,
        },
        twoFactorEnabled: false,
      },
    };
  },

  async updateProfile(
    updates: Partial<UserProfile>,
  ): Promise<UserProfile> {
    const current = await authService.getProfile();

    const updated = {
      ...current,
      ...updates,
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));

    return updated;
  },
};