export type TransactionType = 'income' | 'expense';
export type TransactionStatus = 'completed' | 'pending' | 'failed';
export type TransactionCategory =
  | 'salary'
  | 'freelance'
  | 'investment'
  | 'food'
  | 'transport'
  | 'utilities'
  | 'entertainment'
  | 'shopping'
  | 'health'
  | 'other';

export interface Transaction {
  id: string;
  description: string;
  amount: number;
  type: TransactionType;
  category: TransactionCategory;
  status: TransactionStatus;
  date: string;
  merchant?: string;
}

export interface TransactionFilters {
  search: string;
  type: TransactionType | 'all';
  category: TransactionCategory | 'all';
  status: TransactionStatus | 'all';
}

export interface CreateTransactionPayload {
  description: string;
  amount: number;
  type: TransactionType;
  category: TransactionCategory;
  date: string;
  merchant?: string;
}

export interface DashboardStats {
  currentBalance: number;
  income: number;
  expenses: number;
  savings: number;
  savingsRate: number;
}

export interface ChartDataPoint {
  name: string;
  income: number;
  expenses: number;
}

export interface CategoryDataPoint {
  name: string;
  value: number;
  color: string;
}

export interface TrendDataPoint {
  month: string;
  balance: number;
}
