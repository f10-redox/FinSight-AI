export type InsightPriority = 'high' | 'medium' | 'low';
export type InsightCategory = 'spending' | 'savings' | 'investment' | 'budget';

export interface AIRecommendation {
  id: string;
  title: string;
  description: string;
  category: InsightCategory;
  priority: InsightPriority;
  potentialSavings?: number;
  actionLabel: string;
}

export interface SpendingAnalysis {
  id: string;
  title: string;
  value: string;
  change: number;
  changeLabel: string;
  trend: 'up' | 'down' | 'neutral';
}

export interface FinancialScore {
  overall: number;
  categories: {
    label: string;
    score: number;
    maxScore: number;
  }[];
  lastUpdated: string;
}
