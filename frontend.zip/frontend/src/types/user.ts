export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  createdAt: string;
}

export interface UserSettings {
  currency: string;
  timezone: string;
  notifications: {
    email: boolean;
    push: boolean;
    weeklyReport: boolean;
  };
  twoFactorEnabled: boolean;
}

export interface UserProfile extends User {
  settings: UserSettings;
}
