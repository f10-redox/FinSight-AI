import { Card, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { SparklesIcon } from '../../components/icons/Icons';
import { formatCurrency } from '../../utils/formatters';
import { useAIInsightsData } from './useAIInsightsData';
import styles from './AIInsightsPage.module.css';

const priorityVariant = {
  high: 'danger' as const,
  medium: 'warning' as const,
  low: 'default' as const,
};

const categoryVariant = {
  spending: 'danger' as const,
  savings: 'success' as const,
  investment: 'brand' as const,
  budget: 'info' as const,
};

export function AIInsightsPage() {
  const { recommendations, analysis, score, isLoading } = useAIInsightsData();

  if (isLoading) return <LoadingSpinner fullPage />;

  return (
    <div className={styles.page}>
      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>
          <span className={styles.sectionIcon}>
            <SparklesIcon size={16} />
          </span>
          AI Recommendations
        </h2>
        <div className={styles.recommendationsGrid}>
          {recommendations.map((rec) => (
            <Card key={rec.id} hoverable className={styles.recommendationCard}>
              <div className={styles.recHeader}>
                <span className={styles.recTitle}>{rec.title}</span>
                <div style={{ display: 'flex', gap: 8 }}>
                  <Badge variant={categoryVariant[rec.category]}>
                    {rec.category}
                  </Badge>
                  <Badge variant={priorityVariant[rec.priority]}>
                    {rec.priority}
                  </Badge>
                </div>
              </div>
              <p className={styles.recDescription}>{rec.description}</p>
              <div className={styles.recFooter}>
                {rec.potentialSavings !== undefined && (
                  <span className={styles.savings}>
                    Save up to {formatCurrency(rec.potentialSavings)}/mo
                  </span>
                )}
                <Button variant="ghost" size="sm">
                  {rec.actionLabel}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Spending Analysis</h2>
        <div className={styles.analysisGrid}>
          {analysis.map((item) => (
            <Card key={item.id} className={styles.analysisCard}>
              <span className={styles.analysisTitle}>{item.title}</span>
              <span className={styles.analysisValue}>{item.value}</span>
              <span className={`${styles.analysisChange} ${styles[item.trend]}`}>
                {item.change !== 0 && `${item.change > 0 ? '+' : ''}${item.change}% `}
                {item.changeLabel}
              </span>
            </Card>
          ))}
        </div>
      </section>

      {score && (
        <section className={styles.section}>
          <Card>
            <CardHeader
              title="Financial Health Score"
              description={`Last updated ${new Date(score.lastUpdated).toLocaleDateString()}`}
            />
            <div className={styles.scoreSection}>
              <div className={styles.scoreCircle}>
                <svg width="140" height="140" viewBox="0 0 140 140">
                  <circle
                    cx="70"
                    cy="70"
                    r="60"
                    fill="none"
                    stroke="var(--color-bg-active)"
                    strokeWidth="8"
                  />
                  <circle
                    cx="70"
                    cy="70"
                    r="60"
                    fill="none"
                    stroke="var(--color-brand)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={`${(score.overall / 100) * 377} 377`}
                    transform="rotate(-90 70 70)"
                  />
                </svg>
                <div className={styles.scoreValue}>
                  <span className={styles.scoreNumber}>{score.overall}</span>
                  <span className={styles.scoreLabel}>out of 100</span>
                </div>
              </div>
              <div className={styles.scoreBars}>
                {score.categories.map((cat) => (
                  <div key={cat.label} className={styles.scoreBarItem}>
                    <div className={styles.scoreBarHeader}>
                      <span className={styles.scoreBarLabel}>{cat.label}</span>
                      <span className={styles.scoreBarValue}>
                        {cat.score}/{cat.maxScore}
                      </span>
                    </div>
                    <div className={styles.scoreBarTrack}>
                      <div
                        className={styles.scoreBarFill}
                        style={{ width: `${(cat.score / cat.maxScore) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </section>
      )}
    </div>
  );
}
