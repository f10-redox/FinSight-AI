import { useEffect, useState } from 'react';
import { insightsService } from '../../services';
import type { AIRecommendation, SpendingAnalysis, FinancialScore } from '../../types';

export function useAIInsightsData() {
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [analysis, setAnalysis] = useState<SpendingAnalysis[]>([]);
  const [score, setScore] = useState<FinancialScore | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const [recs, analysisData, scoreData] = await Promise.all([
          insightsService.getRecommendations(),
          insightsService.getSpendingAnalysis(),
          insightsService.getFinancialScore(),
        ]);
        if (!cancelled) {
          setRecommendations(recs);
          setAnalysis(analysisData);
          setScore(scoreData);
        }
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return { recommendations, analysis, score, isLoading };
}
