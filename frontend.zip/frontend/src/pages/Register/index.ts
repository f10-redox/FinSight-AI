export { RegisterPage } from './RegisterPage';
