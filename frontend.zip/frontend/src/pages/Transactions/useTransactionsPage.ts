import { useCallback, useEffect, useState } from 'react';
import { transactionService } from '../../services';
import type {
  Transaction,
  TransactionFilters,
  CreateTransactionPayload,
} from '../../types';

const DEFAULT_FILTERS: TransactionFilters = {
  search: '',
  type: 'all',
  category: 'all',
  status: 'all',
};

export function useTransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filters, setFilters] = useState<TransactionFilters>(DEFAULT_FILTERS);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadTransactions = useCallback(async (currentFilters: TransactionFilters) => {
    setIsLoading(true);
    try {
      const data = await transactionService.getFiltered(currentFilters);
      setTransactions(data);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      loadTransactions(filters);
    }, filters.search ? 300 : 0);
    return () => clearTimeout(timer);
  }, [filters, loadTransactions]);

  const updateFilter = <K extends keyof TransactionFilters>(
    key: K,
    value: TransactionFilters[K],
  ) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const addTransaction = async (payload: CreateTransactionPayload) => {
    setIsSubmitting(true);
    try {
      await transactionService.create(payload);
      setIsModalOpen(false);
      await loadTransactions(filters);
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    transactions,
    filters,
    isLoading,
    isModalOpen,
    isSubmitting,
    updateFilter,
    setIsModalOpen,
    addTransaction,
  };
}
