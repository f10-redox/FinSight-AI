import { useState, type FormEvent } from 'react';
import { Card } from '../../components/ui/Card';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { Button } from '../../components/ui/Button';
import { Modal } from '../../components/ui/Modal';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { TransactionTable } from '../../components/transactions/TransactionTable';
import { SearchIcon, PlusIcon } from '../../components/icons/Icons';
import type { CreateTransactionPayload, TransactionCategory, TransactionType } from '../../types';
import { useTransactionsPage } from './useTransactionsPage';
import styles from './TransactionsPage.module.css';

const TYPE_OPTIONS = [
  { value: 'all', label: 'All Types' },
  { value: 'income', label: 'Income' },
  { value: 'expense', label: 'Expense' },
];

const CATEGORY_OPTIONS = [
  { value: 'all', label: 'All Categories' },
  { value: 'salary', label: 'Salary' },
  { value: 'freelance', label: 'Freelance' },
  { value: 'investment', label: 'Investment' },
  { value: 'food', label: 'Food' },
  { value: 'transport', label: 'Transport' },
  { value: 'utilities', label: 'Utilities' },
  { value: 'entertainment', label: 'Entertainment' },
  { value: 'shopping', label: 'Shopping' },
  { value: 'health', label: 'Health' },
  { value: 'other', label: 'Other' },
];

const STATUS_OPTIONS = [
  { value: 'all', label: 'All Statuses' },
  { value: 'completed', label: 'Completed' },
  { value: 'pending', label: 'Pending' },
  { value: 'failed', label: 'Failed' },
];

const EMPTY_FORM: CreateTransactionPayload = {
  description: '',
  amount: 0,
  type: 'expense',
  category: 'other',
  date: new Date().toISOString().split('T')[0],
  merchant: '',
};

export function TransactionsPage() {
  const {
    transactions,
    filters,
    isLoading,
    isModalOpen,
    isSubmitting,
    updateFilter,
    setIsModalOpen,
    addTransaction,
  } = useTransactionsPage();

  const [form, setForm] = useState<CreateTransactionPayload>(EMPTY_FORM);

  const handleOpenModal = () => {
    setForm({ ...EMPTY_FORM, date: new Date().toISOString().split('T')[0] });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    await addTransaction(form);
    setForm(EMPTY_FORM);
  };

  return (
    <div className={styles.page}>
      <div className={styles.toolbar}>
        <div className={styles.searchWrapper}>
          <Input
            placeholder="Search transactions..."
            value={filters.search}
            onChange={(e) => updateFilter('search', e.target.value)}
            icon={<SearchIcon size={16} />}
          />
        </div>

        <div className={styles.filters}>
          <div className={styles.filterSelect}>
            <Select
              options={TYPE_OPTIONS}
              value={filters.type}
              onChange={(e) =>
                updateFilter('type', e.target.value as TransactionType | 'all')
              }
            />
          </div>
          <div className={styles.filterSelect}>
            <Select
              options={CATEGORY_OPTIONS}
              value={filters.category}
              onChange={(e) =>
                updateFilter('category', e.target.value as TransactionCategory | 'all')
              }
            />
          </div>
          <div className={styles.filterSelect}>
            <Select
              options={STATUS_OPTIONS}
              value={filters.status}
              onChange={(e) =>
                updateFilter('status', e.target.value as typeof filters.status)
              }
            />
          </div>
        </div>

        <div className={styles.actions}>
          <Button icon={<PlusIcon size={16} />} onClick={handleOpenModal}>
            Add Transaction
          </Button>
        </div>
      </div>

      <Card noPadding>
        {isLoading ? (
          <LoadingSpinner />
        ) : (
          <TransactionTable
            transactions={transactions}
            emptyMessage="No transactions match your filters"
          />
        )}
      </Card>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add Transaction"
        footer={
          <>
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button
              isLoading={isSubmitting}
              onClick={handleSubmit}
            >
              Add Transaction
            </Button>
          </>
        }
      >
        <form onSubmit={handleSubmit}>
          <Input
            label="Description"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            required
          />
          <Input
            label="Amount"
            type="number"
            min="0"
            step="0.01"
            value={form.amount || ''}
            onChange={(e) =>
              setForm({ ...form, amount: parseFloat(e.target.value) || 0 })
            }
            required
          />
          <Select
            label="Type"
            options={[
              { value: 'income', label: 'Income' },
              { value: 'expense', label: 'Expense' },
            ]}
            value={form.type}
            onChange={(e) =>
              setForm({ ...form, type: e.target.value as TransactionType })
            }
          />
          <Select
            label="Category"
            options={CATEGORY_OPTIONS.filter((o) => o.value !== 'all')}
            value={form.category}
            onChange={(e) =>
              setForm({ ...form, category: e.target.value as TransactionCategory })
            }
          />
          <Input
            label="Date"
            type="date"
            value={form.date}
            onChange={(e) => setForm({ ...form, date: e.target.value })}
            required
          />
          <Input
            label="Merchant (optional)"
            value={form.merchant ?? ''}
            onChange={(e) => setForm({ ...form, merchant: e.target.value })}
          />
        </form>
      </Modal>
    </div>
  );
}
