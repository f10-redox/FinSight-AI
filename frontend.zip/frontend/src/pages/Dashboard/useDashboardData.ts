import { useEffect, useState } from 'react';
import { transactionService } from '../../services';
import type {
  DashboardStats,
  ChartDataPoint,
  CategoryDataPoint,
  TrendDataPoint,
  Transaction,
} from '../../types';

interface DashboardData {
  stats: DashboardStats | null;
  incomeExpenses: ChartDataPoint[];
  categories: CategoryDataPoint[];
  trend: TrendDataPoint[];
  recentTransactions: Transaction[];
  isLoading: boolean;
  error: string | null;
}

export function useDashboardData(): DashboardData {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [incomeExpenses, setIncomeExpenses] = useState<ChartDataPoint[]>([]);
  const [categories, setCategories] = useState<CategoryDataPoint[]>([]);
  const [trend, setTrend] = useState<TrendDataPoint[]>([]);
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const [statsData, chartData, categoryData, trendData, recent] =
          await Promise.all([
            transactionService.getDashboardStats(),
            transactionService.getIncomeVsExpensesChart(),
            transactionService.getSpendingCategories(),
            transactionService.getMonthlyTrend(),
            transactionService.getRecent(5),
          ]);

        if (!cancelled) {
          setStats(statsData);
          setIncomeExpenses(chartData);
          setCategories(categoryData);
          setTrend(trendData);
          setRecentTransactions(recent);
        }
      } catch {
        if (!cancelled) {
          setError('Failed to load dashboard data');
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return {
    stats,
    incomeExpenses,
    categories,
    trend,
    recentTransactions,
    isLoading,
    error,
  };
}
