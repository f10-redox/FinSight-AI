import { Link } from 'react-router-dom';
import { StatCard } from '../../components/ui/StatCard';
import { Card, CardHeader } from '../../components/ui/Card';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { Button } from '../../components/ui/Button';
import { TransactionTable } from '../../components/transactions/TransactionTable';
import { IncomeExpensesChart } from '../../components/charts/IncomeExpensesChart';
import { SpendingCategoriesChart } from '../../components/charts/SpendingCategoriesChart';
import { MonthlyTrendChart } from '../../components/charts/MonthlyTrendChart';
import {
  WalletIcon,
  TrendUpIcon,
  TrendDownIcon,
  PiggyBankIcon,
  ChevronRightIcon,
} from '../../components/icons/Icons';
import { formatCurrency } from '../../utils/formatters';
import { useDashboardData } from './useDashboardData';
import styles from './DashboardPage.module.css';

export function DashboardPage() {
  const {
    stats,
    incomeExpenses,
    categories,
    trend,
    recentTransactions,
    isLoading,
    error,
  } = useDashboardData();

  if (isLoading) return <LoadingSpinner fullPage />;
  if (error || !stats) {
    return <div className={styles.page}>{error ?? 'Unable to load dashboard'}</div>;
  }

  return (
    <div className={styles.page}>
      <div className={styles.statsGrid}>
        <StatCard
          label="Current Balance"
          value={formatCurrency(stats.currentBalance)}
          icon={<WalletIcon size={18} />}
          iconVariant="brand"
          change={4.2}
          changeLabel="vs last month"
        />
        <StatCard
          label="Income"
          value={formatCurrency(stats.income)}
          icon={<TrendUpIcon size={18} />}
          iconVariant="success"
          change={12.5}
          changeLabel="vs last month"
        />
        <StatCard
          label="Expenses"
          value={formatCurrency(stats.expenses)}
          icon={<TrendDownIcon size={18} />}
          iconVariant="danger"
          change={-8.2}
          changeLabel="vs last month"
        />
        <StatCard
          label="Savings"
          value={formatCurrency(stats.savings)}
          icon={<PiggyBankIcon size={18} />}
          iconVariant="info"
          change={stats.savingsRate}
          changeLabel="savings rate"
        />
      </div>

      <div className={styles.chartsGrid}>
        <Card>
          <CardHeader title="Income vs Expenses" description="Last 6 months" />
          <IncomeExpensesChart data={incomeExpenses} />
        </Card>

        <Card>
          <CardHeader title="Spending Categories" description="Current period breakdown" />
          <SpendingCategoriesChart data={categories} />
          <div className={styles.categoryLegend}>
            {categories.map((cat) => (
              <div key={cat.name} className={styles.legendItem}>
                <span
                  className={styles.legendDot}
                  style={{ background: cat.color }}
                />
                {cat.name}
              </div>
            ))}
          </div>
        </Card>

        <Card className={styles.chartFull}>
          <CardHeader title="Monthly Trend" description="Account balance over time" />
          <MonthlyTrendChart data={trend} />
        </Card>
      </div>

      <Card noPadding>
        <div style={{ padding: 'var(--space-6) var(--space-6) 0' }}>
          <CardHeader
            title="Recent Transactions"
            description="Your latest financial activity"
            action={
              <Link to="/transactions">
                <Button variant="ghost" size="sm" icon={<ChevronRightIcon size={16} />}>
                  View all
                </Button>
              </Link>
            }
          />
        </div>
        <TransactionTable transactions={recentTransactions} compact />
      </Card>
    </div>
  );
}
