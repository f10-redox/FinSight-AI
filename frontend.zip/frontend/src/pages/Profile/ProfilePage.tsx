import { Card, CardHeader } from '../../components/ui/Card';
import { Select } from '../../components/ui/Select';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { getInitials, formatDate } from '../../utils/formatters';
import { useProfilePage } from './useProfilePage';
import styles from './ProfilePage.module.css';

export function ProfilePage() {
  const { profile, isLoading, toggleNotification, updateSettings } =
    useProfilePage();

  if (isLoading || !profile) return <LoadingSpinner fullPage />;

  return (
    <div className={styles.page}>
      <Card>
        <div className={styles.profileHeader}>
          <div className={styles.avatar}>
            {getInitials(profile.firstName, profile.lastName)}
          </div>
          <div className={styles.profileInfo}>
            <h2 className={styles.profileName}>
              {profile.firstName} {profile.lastName}
            </h2>
            <p className={styles.profileEmail}>{profile.email}</p>
            <p className={styles.profileMeta}>
              Member since {formatDate(profile.createdAt)}
            </p>
          </div>
        </div>
      </Card>

      <Card>
        <CardHeader title="Account Settings" description="Manage your preferences" />
        <div className={styles.settingsGrid}>
          <div className={styles.formGrid}>
            <Select
              label="Currency"
              options={[
                { value: 'USD', label: 'USD — US Dollar' },
                { value: 'EUR', label: 'EUR — Euro' },
                { value: 'GBP', label: 'GBP — British Pound' },
              ]}
              value={profile.settings.currency}
              onChange={(e) => updateSettings('currency', e.target.value)}
            />
            <Select
              label="Timezone"
              options={[
                { value: 'America/New_York', label: 'Eastern Time (ET)' },
                { value: 'America/Chicago', label: 'Central Time (CT)' },
                { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
                { value: 'Europe/London', label: 'GMT / London' },
              ]}
              value={profile.settings.timezone}
              onChange={(e) => updateSettings('timezone', e.target.value)}
            />
          </div>

          <div className={styles.settingRow}>
            <div className={styles.settingInfo}>
              <span className={styles.settingLabel}>Email notifications</span>
              <span className={styles.settingDescription}>
                Receive alerts about transactions and insights
              </span>
            </div>
            <button
              className={`${styles.toggle} ${profile.settings.notifications.email ? styles.active : ''}`}
              onClick={() => toggleNotification('email')}
              aria-pressed={profile.settings.notifications.email}
            >
              <span className={styles.toggleThumb} />
            </button>
          </div>

          <div className={styles.settingRow}>
            <div className={styles.settingInfo}>
              <span className={styles.settingLabel}>Push notifications</span>
              <span className={styles.settingDescription}>
                Get real-time alerts on your device
              </span>
            </div>
            <button
              className={`${styles.toggle} ${profile.settings.notifications.push ? styles.active : ''}`}
              onClick={() => toggleNotification('push')}
              aria-pressed={profile.settings.notifications.push}
            >
              <span className={styles.toggleThumb} />
            </button>
          </div>

          <div className={styles.settingRow}>
            <div className={styles.settingInfo}>
              <span className={styles.settingLabel}>Weekly report</span>
              <span className={styles.settingDescription}>
                Receive a summary of your financial activity every week
              </span>
            </div>
            <button
              className={`${styles.toggle} ${profile.settings.notifications.weeklyReport ? styles.active : ''}`}
              onClick={() => toggleNotification('weeklyReport')}
              aria-pressed={profile.settings.notifications.weeklyReport}
            >
              <span className={styles.toggleThumb} />
            </button>
          </div>

          <div className={styles.settingRow}>
            <div className={styles.settingInfo}>
              <span className={styles.settingLabel}>Two-factor authentication</span>
              <span className={styles.settingDescription}>
                Add an extra layer of security to your account
              </span>
            </div>
            <button
              className={`${styles.toggle} ${profile.settings.twoFactorEnabled ? styles.active : ''}`}
              onClick={() =>
                updateSettings('twoFactorEnabled', !profile.settings.twoFactorEnabled)
              }
              aria-pressed={profile.settings.twoFactorEnabled}
            >
              <span className={styles.toggleThumb} />
            </button>
          </div>
        </div>
      </Card>
    </div>
  );
}
