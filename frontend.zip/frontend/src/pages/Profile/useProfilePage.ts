import { useEffect, useState } from 'react';
import { authService } from '../../services';
import type { UserProfile } from '../../types';

export function useProfilePage() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    authService.getProfile().then((data) => {
      setProfile(data);
      setIsLoading(false);
    });
  }, []);

  const updateSettings = async (
    key: keyof UserProfile['settings'],
    value: UserProfile['settings'][typeof key],
  ) => {
    if (!profile) return;
    const updated = {
      ...profile,
      settings: { ...profile.settings, [key]: value },
    };
    setProfile(updated);
    setIsSaving(true);
    try {
      await authService.updateProfile(updated);
    } finally {
      setIsSaving(false);
    }
  };

  const toggleNotification = async (
    key: keyof UserProfile['settings']['notifications'],
  ) => {
    if (!profile) return;
    const updated = {
      ...profile,
      settings: {
        ...profile.settings,
        notifications: {
          ...profile.settings.notifications,
          [key]: !profile.settings.notifications[key],
        },
      },
    };
    setProfile(updated);
    await authService.updateProfile(updated);
  };

  return { profile, isLoading, isSaving, updateSettings, toggleNotification };
}
