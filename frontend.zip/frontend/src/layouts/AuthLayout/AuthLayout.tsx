import { Outlet } from 'react-router-dom';
import { SparklesIcon } from '../../components/icons/Icons';
import styles from './AuthLayout.module.css';

export function AuthLayout() {
  return (
    <div className={styles.layout}>
      <div className={styles.brandPanel}>
        <div className={styles.brandContent}>
          <div className={styles.logo}>
            <div className={styles.logoIcon}>
              <SparklesIcon size={20} />
            </div>
            <span className={styles.logoName}>FinSight AI</span>
          </div>
          <h1 className={styles.headline}>
            Smart financial insights, powered by AI
          </h1>
          <p className={styles.subheadline}>
            Track spending, analyze trends, and receive personalized
            recommendations to grow your wealth with confidence.
          </p>
          <ul className={styles.features}>
            {[
              'Real-time transaction tracking and categorization',
              'AI-powered spending analysis and recommendations',
              'Beautiful dashboards with actionable insights',
            ].map((text) => (
              <li key={text} className={styles.feature}>
                <span className={styles.featureDot} />
                <span className={styles.featureText}>{text}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className={styles.formPanel}>
        <div className={styles.formContainer}>
          <Outlet />
        </div>
      </div>
    </div>
  );
}
