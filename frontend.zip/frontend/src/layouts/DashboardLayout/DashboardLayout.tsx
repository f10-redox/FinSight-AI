import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from '../../components/layout/Sidebar';
import { TopBar } from '../../components/layout/TopBar';
import styles from './DashboardLayout.module.css';

const PAGE_META: Record<string, { title: string; subtitle: string }> = {
  '/dashboard': {
    title: 'Dashboard',
    subtitle: 'Overview of your financial activity',
  },
  '/transactions': {
    title: 'Transactions',
    subtitle: 'Manage and track all transactions',
  },
  '/insights': {
    title: 'AI Insights',
    subtitle: 'Personalized financial recommendations',
  },
  '/profile': {
    title: 'Profile',
    subtitle: 'Manage your account settings',
  },
};

export function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const meta = PAGE_META[location.pathname] ?? {
    title: 'FinSight AI',
    subtitle: '',
  };

  return (
    <div className={styles.layout}>
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <div className={styles.main}>
        <TopBar
          title={meta.title}
          subtitle={meta.subtitle}
          onMenuClick={() => setSidebarOpen(true)}
        />
        <main className={styles.content}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
