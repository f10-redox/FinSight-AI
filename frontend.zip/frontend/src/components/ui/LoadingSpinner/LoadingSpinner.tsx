import styles from './LoadingSpinner.module.css';

interface LoadingSpinnerProps {
  fullPage?: boolean;
}

export function LoadingSpinner({ fullPage = false }: LoadingSpinnerProps) {
  return (
    <div
      className={`${styles.spinner} ${fullPage ? styles.fullPage : ''}`}
      role="status"
      aria-label="Loading"
    >
      <div className={styles.ring} />
    </div>
  );
}
