import type { ReactNode } from 'react';
import styles from './StatCard.module.css';

type IconVariant = 'brand' | 'success' | 'danger' | 'info';

interface StatCardProps {
  label: string;
  value: string;
  icon: ReactNode;
  iconVariant?: IconVariant;
  change?: number;
  changeLabel?: string;
}

export function StatCard({
  label,
  value,
  icon,
  iconVariant = 'brand',
  change,
  changeLabel,
}: StatCardProps) {
  const changeClass =
    change !== undefined
      ? change >= 0
        ? styles.positive
        : styles.negative
      : '';

  return (
    <div className={styles.statCard}>
      <div className={styles.header}>
        <span className={styles.label}>{label}</span>
        <div className={`${styles.iconWrapper} ${styles[iconVariant]}`}>
          {icon}
        </div>
      </div>
      <div className={styles.value}>{value}</div>
      {(change !== undefined || changeLabel) && (
        <div className={styles.footer}>
          {change !== undefined && (
            <span className={`${styles.change} ${changeClass}`}>
              {change >= 0 ? '+' : ''}
              {change.toFixed(1)}%
            </span>
          )}
          {changeLabel && (
            <span className={styles.changeLabel}>{changeLabel}</span>
          )}
        </div>
      )}
    </div>
  );
}
