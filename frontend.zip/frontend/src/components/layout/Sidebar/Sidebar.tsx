import { NavLink } from 'react-router-dom';
import {
  DashboardIcon,
  TransactionsIcon,
  InsightsIcon,
  ProfileIcon,
  LogoutIcon,
  SparklesIcon,
} from '../../icons/Icons';
import { useAuth } from '../../../contexts/AuthContext';
import styles from './Sidebar.module.css';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const mainNavItems = [
  { to: '/dashboard', label: 'Dashboard', icon: DashboardIcon },
  { to: '/transactions', label: 'Transactions', icon: TransactionsIcon },
  { to: '/insights', label: 'AI Insights', icon: InsightsIcon },
];

const accountNavItems = [
  { to: '/profile', label: 'Profile', icon: ProfileIcon },
];

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const { logout } = useAuth();

  const handleNavClick = () => {
    if (window.innerWidth <= 1024) {
      onClose();
    }
  };

  return (
    <>
      <div
        className={`${styles.overlay} ${isOpen ? styles.visible : ''}`}
        onClick={onClose}
        aria-hidden="true"
      />
      <aside className={`${styles.sidebar} ${isOpen ? styles.open : ''}`}>
        <div className={styles.logo}>
          <div className={styles.logoIcon}>
            <SparklesIcon size={16} />
          </div>
          <div className={styles.logoText}>
            <span className={styles.logoName}>FinSight AI</span>
            <span className={styles.logoTagline}>Financial Intelligence</span>
          </div>
        </div>

        <nav className={styles.nav}>
          <div className={styles.navSection}>
            <p className={styles.navLabel}>Overview</p>
            <ul className={styles.navList}>
              {mainNavItems.map(({ to, label, icon: Icon }) => (
                <li key={to}>
                  <NavLink
                    to={to}
                    className={({ isActive }) =>
                      `${styles.navLink} ${isActive ? styles.active : ''}`
                    }
                    onClick={handleNavClick}
                  >
                    <span className={styles.navIcon}>
                      <Icon size={18} />
                    </span>
                    {label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>

          <div className={styles.navSection}>
            <p className={styles.navLabel}>Account</p>
            <ul className={styles.navList}>
              {accountNavItems.map(({ to, label, icon: Icon }) => (
                <li key={to}>
                  <NavLink
                    to={to}
                    className={({ isActive }) =>
                      `${styles.navLink} ${isActive ? styles.active : ''}`
                    }
                    onClick={handleNavClick}
                  >
                    <span className={styles.navIcon}>
                      <Icon size={18} />
                    </span>
                    {label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        </nav>

        <div className={styles.footer}>
          <button className={styles.logoutBtn} onClick={logout}>
            <LogoutIcon size={18} />
            Sign out
          </button>
        </div>
      </aside>
    </>
  );
}
