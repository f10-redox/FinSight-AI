import { Link } from 'react-router-dom';
import { MenuIcon, BellIcon } from '../../icons/Icons';
import { useAuth } from '../../../contexts/AuthContext';
import { getInitials } from '../../../utils/formatters';
import styles from './TopBar.module.css';

interface TopBarProps {
  title: string;
  subtitle?: string;
  onMenuClick: () => void;
}

export function TopBar({ title, subtitle, onMenuClick }: TopBarProps) {
  const { user } = useAuth();

  return (
    <header className={styles.topbar}>
      <div className={styles.left}>
        <button
          className={styles.menuBtn}
          onClick={onMenuClick}
          aria-label="Open menu"
        >
          <MenuIcon size={20} />
        </button>
        <div className={styles.pageInfo}>
          <h1 className={styles.pageTitle}>{title}</h1>
          {subtitle && <p className={styles.pageSubtitle}>{subtitle}</p>}
        </div>
      </div>

      <div className={styles.right}>
        <button className={styles.iconBtn} aria-label="Notifications">
          <BellIcon size={18} />
          <span className={styles.notificationDot} />
        </button>

        {user && (
          <Link to="/profile" className={styles.userMenu}>
            <div className={styles.avatar}>
              {getInitials(user.firstName, user.lastName)}
            </div>
            <div className={styles.userInfo}>
              <span className={styles.userName}>
                {user.firstName} {user.lastName}
              </span>
              <span className={styles.userEmail}>{user.email}</span>
            </div>
          </Link>
        )}
      </div>
    </header>
  );
}
