import { Badge } from '../../ui/Badge';
import { Table, type Column } from '../../ui/Table';
import type { Transaction } from '../../../types';
import { formatCurrency, formatDate, capitalize } from '../../../utils/formatters';
import styles from './TransactionTable.module.css';

interface TransactionTableProps {
  transactions: Transaction[];
  emptyMessage?: string;
  compact?: boolean;
}

const statusVariant = {
  completed: 'success' as const,
  pending: 'warning' as const,
  failed: 'danger' as const,
};

export function TransactionTable({
  transactions,
  emptyMessage,
  compact = false,
}: TransactionTableProps) {
  const columns: Column<Transaction>[] = [
    {
      key: 'description',
      header: 'Description',
      render: (txn) => (
        <div className={styles.descriptionCell}>
          <span className={styles.description}>{txn.description}</span>
          {txn.merchant && !compact && (
            <span className={styles.merchant}>{txn.merchant}</span>
          )}
        </div>
      ),
    },
    {
      key: 'category',
      header: 'Category',
      render: (txn) => (
        <Badge variant="default">{capitalize(txn.category)}</Badge>
      ),
    },
    {
      key: 'date',
      header: 'Date',
      render: (txn) => formatDate(txn.date),
    },
    {
      key: 'status',
      header: 'Status',
      render: (txn) => (
        <Badge variant={statusVariant[txn.status]}>
          {capitalize(txn.status)}
        </Badge>
      ),
    },
    {
      key: 'amount',
      header: 'Amount',
      align: 'right',
      render: (txn) => (
        <span
          className={
            txn.type === 'income' ? styles.amountIncome : styles.amountExpense
          }
        >
          {txn.type === 'income' ? '+' : '-'}
          {formatCurrency(txn.amount)}
        </span>
      ),
    },
  ];

  return (
    <Table
      columns={columns}
      data={transactions}
      emptyMessage={emptyMessage}
      keyExtractor={(txn) => txn.id}
    />
  );
}
