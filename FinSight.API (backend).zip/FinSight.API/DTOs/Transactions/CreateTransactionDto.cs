using System.ComponentModel.DataAnnotations;

namespace FinSight.API.DTOs.Transactions
{
    public class CreateTransactionDto
    {
        [Required]
        public decimal Amount { get; set; }

        public string Category { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime? Date { get; set; }
    }
}
