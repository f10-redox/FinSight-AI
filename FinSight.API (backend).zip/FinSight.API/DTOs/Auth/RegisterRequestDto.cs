using System.ComponentModel.DataAnnotations;

namespace FinSight.API.DTOs.Auth
{
    public class RegisterRequestDto
    {
        [Required]
        public string FirstName { get; set; } = null!;

        [Required]
        public string LastName { get; set; } = null!;

        [Required]
        public string Email { get; set; } = null!;

        [Required]
        public string Password { get; set; } = null!;
    }
}