using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using FinSight.API.DTOs.Transactions;
using FinSight.API.Services;

namespace FinSight.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class TransactionsController : ControllerBase
    {
        private readonly ITransactionService _svc;

        public TransactionsController(ITransactionService svc)
        {
            _svc = svc;
        }

        private Guid GetUserId() => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        [HttpPost]
        public async Task<IActionResult> Create(CreateTransactionDto dto)
        {
            var userId = GetUserId();
            var t = await _svc.CreateAsync(userId, dto);
            return Ok(t);
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var userId = GetUserId();
            var list = await _svc.GetForUserAsync(userId);
            return Ok(list);
        }

        [HttpPut]
        public async Task<IActionResult> Update(UpdateTransactionDto dto)
        {
            var userId = GetUserId();
            var updated = await _svc.UpdateAsync(userId, dto);
            if (updated == null) return NotFound();
            return Ok(updated);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var userId = GetUserId();
            var ok = await _svc.DeleteAsync(userId, id);
            if (!ok) return NotFound();
            return NoContent();
        }
    }
}
