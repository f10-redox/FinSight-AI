using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using FinSight.API.Services;

namespace FinSight.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class InsightsController : ControllerBase
    {
        private readonly IInsightService _svc;

        public InsightsController(IInsightService svc)
        {
            _svc = svc;
        }

        private Guid GetUserId() => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var userId = GetUserId();
            var list = await _svc.GetForUserAsync(userId);
            return Ok(list);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateInsightRequest request)
        {
            var userId = GetUserId();
            var insight = await _svc.CreateAsync(userId, request.Title, request.Content);
            return Ok(insight);
        }
    }

    public class CreateInsightRequest
    {
        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
    }
}
