using System.ComponentModel.DataAnnotations;

namespace FinSight.API.Models
{
    // Represents an application user. This maps to the Users table.
    public class User
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        public string Email { get; set; } = null!;

        [Required]
        public string PasswordHash { get; set; } = null!;

        public string FirstName { get; set; } = "";

        public string LastName { get; set; } = "";

        public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();

        public ICollection<AIInsight> AIInsights { get; set; } = new List<AIInsight>();
    }
}