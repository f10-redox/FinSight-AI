using System.ComponentModel.DataAnnotations;

namespace FinSight.API.Models
{
    // Represents an AI generated insight for a user (summary/analysis)
    public class AIInsight
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        public Guid UserId { get; set; }
        public User? User { get; set; }

        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
