using FinSight.API.DTOs.Auth;

namespace FinSight.API.Services
{
    public interface IAuthService
    {
        Task<string> RegisterAsync(RegisterRequestDto dto);
        Task<string> LoginAsync(LoginRequestDto dto);
    }
}
