using FinSight.API.DTOs.Transactions;
using FinSight.API.Models;

namespace FinSight.API.Services
{
    public interface ITransactionService
    {
        Task<Transaction> CreateAsync(Guid userId, CreateTransactionDto dto);
        Task<IEnumerable<Transaction>> GetForUserAsync(Guid userId);
        Task<Transaction?> UpdateAsync(Guid userId, UpdateTransactionDto dto);
        Task<bool> DeleteAsync(Guid userId, Guid transactionId);
    }
}
