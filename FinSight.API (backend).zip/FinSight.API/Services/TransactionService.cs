using Microsoft.EntityFrameworkCore;
using FinSight.API.Data;
using FinSight.API.DTOs.Transactions;
using FinSight.API.Models;

namespace FinSight.API.Services
{
    public class TransactionService : ITransactionService
    {
        private readonly FinSightDbContext _db;

        public TransactionService(FinSightDbContext db)
        {
            _db = db;
        }

        public async Task<Transaction> CreateAsync(Guid userId, CreateTransactionDto dto)
        {
            var t = new Transaction
            {
                UserId = userId,
                Amount = dto.Amount,
                Category = dto.Category,
                Description = dto.Description,
                Date = dto.Date ?? DateTime.UtcNow
            };
            _db.Transactions.Add(t);
            await _db.SaveChangesAsync();
            return t;
        }

        public async Task<IEnumerable<Transaction>> GetForUserAsync(Guid userId)
        {
            return await _db.Transactions.Where(t => t.UserId == userId).ToListAsync();
        }

        public async Task<Transaction?> UpdateAsync(Guid userId, UpdateTransactionDto dto)
        {
            var existing = await _db.Transactions.FirstOrDefaultAsync(t => t.Id == dto.Id && t.UserId == userId);
            if (existing == null) return null;
            existing.Amount = dto.Amount;
            existing.Category = dto.Category;
            existing.Description = dto.Description;
            existing.Date = dto.Date ?? existing.Date;
            await _db.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> DeleteAsync(Guid userId, Guid transactionId)
        {
            var existing = await _db.Transactions.FirstOrDefaultAsync(t => t.Id == transactionId && t.UserId == userId);
            if (existing == null) return false;
            _db.Transactions.Remove(existing);
            await _db.SaveChangesAsync();
            return true;
        }
    }
}
