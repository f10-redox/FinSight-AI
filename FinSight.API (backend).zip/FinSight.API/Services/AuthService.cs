using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using FinSight.API.Data;
using FinSight.API.DTOs.Auth;
using FinSight.API.Models;

namespace FinSight.API.Services
{
    // Simple AuthService that handles registration and JWT creation.
    public class AuthService : IAuthService
    {
        private readonly FinSightDbContext _db;
        private readonly IConfiguration _cfg;

        public AuthService(FinSightDbContext db, IConfiguration cfg)
        {
            _db = db;
            _cfg = cfg;
        }

        public async Task<string> RegisterAsync(RegisterRequestDto dto)
        {
            var exists = await _db.Users.AnyAsync(u => u.Email == dto.Email);

            if (exists)
                throw new Exception("User already exists");

            var user = new User
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                PasswordHash = Hash(dto.Password)
            };

            _db.Users.Add(user);

            await _db.SaveChangesAsync();

            return GenerateToken(user);
        }

        public async Task<string> LoginAsync(LoginRequestDto dto)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == dto.Email);

            if (user == null || !VerifyHash(dto.Password, user.PasswordHash))
                throw new Exception("Invalid credentials");

            return GenerateToken(user);
        }

        private string GenerateToken(User user)
        {
            var key = Encoding.UTF8.GetBytes(
                _cfg["Jwt:Key"] ?? "ReplaceThisWithAStrongKeyForDevOnly"
            );

            var creds = new SigningCredentials(
                new SymmetricSecurityKey(key),
                SecurityAlgorithms.HmacSha256
            );

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Email, user.Email)
            };

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.UtcNow.AddDays(7),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private static string Hash(string input)
        {
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
            return Convert.ToBase64String(bytes);
        }

        private static bool VerifyHash(string input, string hash)
            => Hash(input) == hash;
    }
}