using FinSight.API.Models;

namespace FinSight.API.Services
{
    public interface IInsightService
    {
        Task<AIInsight> CreateAsync(Guid userId, string title, string content);
        Task<IEnumerable<AIInsight>> GetForUserAsync(Guid userId);
    }
}
