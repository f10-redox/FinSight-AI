using FinSight.API.Data;
using FinSight.API.Models;
using Microsoft.EntityFrameworkCore;

namespace FinSight.API.Services
{
    public class InsightService : IInsightService
    {
        private readonly FinSightDbContext _db;

        public InsightService(FinSightDbContext db)
        {
            _db = db;
        }

        public async Task<AIInsight> CreateAsync(Guid userId, string title, string content)
        {
            var insight = new AIInsight
            {
                UserId = userId,
                Title = title,
                Content = content,
                CreatedAt = DateTime.UtcNow
            };
            _db.AIInsights.Add(insight);
            await _db.SaveChangesAsync();
            return insight;
        }

        public async Task<IEnumerable<AIInsight>> GetForUserAsync(Guid userId)
        {
            return await _db.AIInsights.Where(i => i.UserId == userId).ToListAsync();
        }
    }
}
