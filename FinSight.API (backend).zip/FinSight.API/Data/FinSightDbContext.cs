using Microsoft.EntityFrameworkCore;
using FinSight.API.Models;

namespace FinSight.API.Data
{
    // FinSightDbContext is the EF Core DbContext which maps C# models to Postgres tables
    public class FinSightDbContext : DbContext
    {
        public FinSightDbContext(DbContextOptions<FinSightDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Transaction> Transactions { get; set; } = null!;
        public DbSet<AIInsight> AIInsights { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>(b =>
            {
                b.HasKey(u => u.Id);

                b.HasMany(u => u.Transactions)
                    .WithOne(t => t.User!)
                    .HasForeignKey(t => t.UserId);

                b.HasMany(u => u.AIInsights)
                    .WithOne(i => i.User!)
                    .HasForeignKey(i => i.UserId);
            });
        }
    }
}